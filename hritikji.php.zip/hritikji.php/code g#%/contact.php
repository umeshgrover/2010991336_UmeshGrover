<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="contact.css" type="text/css" rel="stylesheet" />
</head>

<body>
<div id="a"><!--a-->
<div class="b"><!--b-->
<h1 class="c"><i>Online Shoping</i></h1>
</div><!--b-->
<div class="d"><!--d-->
<table class="e">
<tr><th><a class="f" href="home.php">HOME</a></th><th><a class="f" href="contact.php">CONTACT US</a></th><th><a class="f" href="product.php">PRODUCTS</a></th>
<th><a class="f" href="about.php">ABOUT US</a></th><th><a class="f" href="feedback.php">FEEDBACK</a></th><th><a class="f" href="signup.php">SIGN UP</a>
</th></tr>
</table>
</div><!--d-->
<hr class="g" />
<div class="h"><!--h-->
<div class="i"><!--i-->
<h1 class="j">CONTACT US</h1>
<form name="f" method="post" action="cont.php" onsubmit="return val()">
<table class="k">
<tr><td>First Name</td><td><input class="k1" type="text" name="t1" /></td></tr>
<tr><td>Last Name</td><td><input class="k1" type="text" name="t2" /></td></tr>
<tr><td>Email</td><td><input class="k1" type="text" name="t3" /></td></tr>
<tr><td>Address</td><td><textarea class="k1" name="t4"></textarea></td></tr>
<tr><td>Phone no.</td><td><input class="k1" type="text" name="t5" /></td></tr>
<tr><td>Subject</td><td><input class="k1" type="text" name="t6" /></td></tr>
<tr><td>Message</td><td><textarea class="k1" name="t7"></textarea></td></tr>
<tr><td colspan="2"><input class="k2" type="submit" value="Sent" /></td></tr>
</table>
</form>
</div><!--i-->
<div class="n"><!--n-->
<img class="o" src="image/Apple.jpg" />
</div><!--n-->
</div><!--h-->
<hr class="g" />
<div class="p"><!--p-->
<div class="q"><!--q-->
<h1 class="j">We do appreciate your feedback</h1>
<pre class="r"> We will be glad to hear from you if:
- You have found a mistake in our phone specifications.
- You have info about a phone which we don't have in our
  database.
- You have found a broken link.
- You have a suggestion for improving GSMArena.com or you want  
  to request a feature.

Before sending us an email, please keep in mind:
- We do not sell mobile phones.
- We do not know the price of any mobile phone in your country.
- We don't answer any "unlocking" related questions.
- We don't answer any "Which mobile should I buy?" questions. </pre>
</div><!--q-->
<div class="s"><!--s-->
<img class="t" src="image/samsung-galaxy-s3.jpg" />
</div><!--s-->
</div><!--p-->
<hr class="g" />
<div class="u"><!--u-->
<table class="e">
<tr><th><a class="f" href="home.php">HOME</a></th><th><a class="f" href="contact.php">CONTACT US</a></th><th><a class="f" href="product.php">PRODUCTS</a></th>
<th><a class="f" href="about.php">ABOUT US</a></th><th><a class="f" href="feedback.php">FEEDBACK</a></th><th><a class="f" href="signup.php">SIGN UP</a>
</th></tr>
</table>
</div><!--u-->
<hr class="g" />
<div class="u"><!--v-->
<pre class="v">Copy Right 2013 Company Name Mobile Site
       E-mail:-<a class="w" href="#">amar9021@gmail.com</a></pre>
</div><!--v-->
</div><!--a-->
</body>
</html>
