<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="about.css" type="text/css" rel="stylesheet" />
</head>

<body>
<div id="a"><!--a-->
<div class="b"><!--b-->
<h1 class="c"><i>Mobile Mania</i></h1>
</div><!--b-->
<div class="d"><!--d-->
<table class="e">
<tr><th><a class="f" href="home.php">HOME</a></th><th><a class="f" href="contact.php">CONTACT US</a></th><th><a class="f" href="product.php">PRODUCTS</a></th>
<th><a class="f" href="about.php">ABOUT US</a></th><th><a class="f" href="feedback.php">FEEDBACK</a></th><th><a class="f" href="signup.php">SIGN UP</a>
</th></tr>
</table>
</div><!--d-->
<hr class="g" />
<div class="h"><!--h-->
<h1 class="i">About Mobile Mania</h1>
<hr class="j" />
<p class="k">Welcome to Mobile Mania. For over 5 years, Mobile Mania has been dedicated to making a better world through diverse
businesses that today span advanced technology, semiconductors, skyscraper and plant construction,
petrochemicals, fashion, finance, hotels, and more. Our flagship company, GSM ARENA,
leads the global market in high-tech electronics manufacturing and digital media.</p>
<p class="l">Through innovative, reliable products and services; talented people; a responsible approach to business and global citizenship; and collaboration with our partners and customers, Mobile Mania is taking the world in imaginative new directions.</p>
</div><!--h-->
<div class="m"><!--m-->
<div class="n"><!--n-->
<img class="o" src="image/main_visual.gif" />
</div><!--n-->
<div class="p"><!--p-->
<div class="q"><!--q-->
<h1 class="q1">Our Citizenship Focus</h1>
<p class="q2">Mobile Mania's citizenship efforts encompass a broad range of areas that touch people's lives, including social welfare, culture and arts, volunteer services, academics and education, environmental protection, and international exchanges.</p>
</div><!--q-->
<div class="r"><!--r-->
<h1 class="q1">Vision</h1>
<p class="q2">Mobile Mania is dedicated to developing innovative technologies and efficient processes that create new markets, enrich people's lives, and continue to make Mobile Mania a digital leader. </p>
</div><!--r-->
<div class="s"><!--s-->
<h1 class="q1">History</h1>
<p class="q2">For more than 5 years, Samsung has been at the forefront of innovation. Our discoveries, inventions and breakthrough products have helped shape the history of the digital revolution.</p>
</div><!--s-->
<div class="t"><!--t-->
<h1 class="q1">Our Performance</h1>
<p class="q2">At Mobile Mania our gaze is cast forward, beyond the next quarter or the next year, ahead into areas unknown. By charting a course toward new businesses and new challenges, we are sowing seeds for future success.</p>
</div><!--t-->
</div><!--p-->
</div><!--m-->
<hr class="g" />
<div class="u"><!--u-->
<table class="e">
<tr><th><a class="f" href="home.php">HOME</a></th><th><a class="f" href="contact.php">CONTACT US</a></th><th><a class="f" href="product.php">PRODUCTS</a></th>
<th><a class="f" href="about.php">ABOUT US</a></th><th><a class="f" href="feedback.php">FEEDBACK</a></th><th><a class="f" href="signup.php">SIGN UP</a>
</th></tr>
</table>
</div><!--u-->
<hr class="g" />
<div class="u"><!--t-->
<pre class="v">Copy Right 2013 Company Name Mobile Site
       E-mail:-<a class="w" href="#">amar9021@gmail.com</a></pre>
</div><!--t-->

</div><!--a-->
</body>
</html>
